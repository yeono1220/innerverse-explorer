// 16 · 모모 대화 (말풍선 + 실시간 감정 태깅 + 추천 답변)
import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { StatusBar, AppBar, Body, IconButton } from "../ui/layout";
import { Momo2D } from "../ui/planet";
import { EmotionDot } from "../ui/emotion";
import type { EmotionLabel } from "@/store/diaryStore";
import { momoReply } from "@/lib/api";
import { ragContext } from "@/services/rag";
import { getMemory, memoryPromptBlock } from "@/services/memory";
import { CareSheet } from "../ui/CareSheet";
import { useAppStore, MOMO_QUEST_TURNS } from "@/store/appStore";
import { useUsageStore } from "@/store/usageStore";
import { useUserStore } from "@/store/userStore";
import { PlanNotice } from "../ui/PlanNotice";
import { isUnlimited, limitsFor } from "@/lib/plan";

interface Msg {
  id: number;
  who: "momo" | "me";
  text: string;
  emo?: EmotionLabel;
  memory?: string[]; // RAG로 참조한 과거 일기 미리보기
}

const SUGGESTIONS = ["조금 무기력해", "오늘 좀 신났어", "긴장돼서 잠이 안 와", "그냥 평범한 하루였어"];

const REPLIES: Array<{ keys: RegExp; reply: string; emo: EmotionLabel }> = [
  { keys: /무기력|공허|텅|허무/, reply: "텅 빈 느낌이 들었구나. 그런 날엔 무언가 안 해도 괜찮아.", emo: "공허" },
  { keys: /사랑|보고싶|그리워|애틋|설레|따뜻/, reply: "따뜻한 마음이 번졌구나. 그 온기 오래 간직해 🌸", emo: "사랑" },
  { keys: /신났|기뻤|좋았|행복|뿌듯/, reply: "와, 좋은 일이 있었구나! 그 기억 오래 머물게 해줄게 ✨", emo: "기쁨" },
  { keys: /화가|화났|짜증|억울|열받|분노/, reply: "많이 화났겠다. 그럴 만했어. 그 감정도 네 마음의 신호야.", emo: "분노" },
  { keys: /불안|긴장|초조|걱정/, reply: "긴장됐겠다. 호흡 한번 같이 해볼까? 들이쉬고… 천천히 내쉬고.", emo: "긴장" },
  { keys: /슬|눈물|외|지쳤|아프/, reply: "많이 무거웠지. 내가 곁에 있어. 천천히 얘기해줘.", emo: "슬픔" },
  { keys: /평범|괜찮|담담|쉬/, reply: "잔잔한 하루였구나. 그 결도 행성 위에 차곡차곡 쌓일 거야 🌿", emo: "차분" },
];

export default function MomoChat() {
  const nav = useNavigate();
  const completeQuest = useAppStore((s) => s.completeQuest);
  // 무료 플랜: 하루 대화 턴 제한 (구독자는 무제한)
  const chatTurns = useUsageStore((s) => s.chatTurns);
  const consumeChatTurn = useUsageStore((s) => s.consumeChatTurn);
  const ensureFresh = useUsageStore((s) => s.ensureFresh);
  const plan = useUserStore((s) => s.plan);
  const chatLeft = Math.max(0, limitsFor(plan).chatTurnsPerDay - chatTurns);
  const locked = chatLeft <= 0;

  useEffect(() => {
    ensureFresh(); // 날짜가 바뀌었으면 턴 카운터 리셋
  }, [ensureFresh]);
  const [msgs, setMsgs] = useState<Msg[]>([
    { id: 1, who: "momo", text: "오늘 마음은 어때? 천천히, 떠오르는 대로 들려줘 🌙" },
  ]);
  const [input, setInput] = useState("");
  const [careOpen, setCareOpen] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  // 모모챗 세션 id — vLLM 성능 9지표 로깅을 이 대화에 귀속시키기 위함(마운트당 1개)
  const sessionRef = useRef<string>("");
  if (!sessionRef.current) {
    sessionRef.current =
      typeof crypto !== "undefined" && "randomUUID" in crypto
        ? crypto.randomUUID()
        : `momo-${Date.now()}-${Math.round(Math.random() * 1e6)}`;
  }
  const sessionId = sessionRef.current;

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs.length]);

  const send = async (text: string) => {
  const t = text.trim();
  if (!t) return;
  // 무료 플랜 하루 한도 소진 시 전송 차단
  if (!consumeChatTurn()) {
    setMsgs((m) => [
      ...m,
      { id: Date.now(), who: "momo", text: "오늘 나눌 수 있는 이야기를 다 썼어. 내일 다시 만나거나, 플러스로 계속 이어갈 수 있어 🌙" },
    ]);
    setInput("");
    return;
  }
  // 퀘스트 판정은 화면 상태가 아니라 "오늘 누적 발화 수"(usageStore)로 센다.
  // 대화 도중 뒤로 갔다가 다시 들어와도 이어서 카운트된다.
  if (useUsageStore.getState().chatTurns >= MOMO_QUEST_TURNS) completeQuest("q2");
  const rule = REPLIES.find((r) => r.keys.test(t));
  const userMsg: Msg = { id: Date.now(), who: "me", text: t, emo: rule?.emo };

  // 사용자 메시지 + '생각 중' 버블을 즉시 표시 → 멈춘 느낌 제거
  const thinkingId = userMsg.id + 1;
  setMsgs((m) => [...m, userMsg, { id: thinkingId, who: "momo", text: "…" }]);
  setInput("");

    // 최근 6개 대화 기록을 history로 전달
  const history = [...msgs, userMsg].slice(-6).map((m) => `${m.who}: ${m.text}`);

    // RAG: 과거 일기 검색 → 모모 답장에 컨텍스트 주입
  let reply = rule?.reply ?? "조금 더 들려줄래? 어떤 순간이었는지.";
  let memory: string[] = [];
  try {
    // 서로 독립인 두 조회를 병렬로 (직렬 → 병렬)
    const [hits, mem] = await Promise.all([ragContext(t), getMemory()]);
    memory = hits.map((h) => h.preview);
    const r = await momoReply({
      text: t,
      context: hits.map((h) => h.snippet),
      history,
      profile: memoryPromptBlock(mem),
      session_id: sessionId,
    });
    if (r?.reply) reply = r.reply;
    if (r?.escalate) window.setTimeout(() => setCareOpen(true), 700);
  } catch {
    /* 백엔드 실패 → 로컬 규칙 답장 유지 */
  }
  // '생각 중' 버블을 실제 답장으로 교체
  setMsgs((m) => m.map((msg) => (msg.id === thinkingId ? { ...msg, text: reply, memory } : msg)));
};

  return (
    <>
      <StatusBar />
      <AppBar
        back
        title={isUnlimited(chatLeft) ? "모모와 대화" : `모모와 대화 · ${chatLeft}턴`}
        right={
          <IconButton onClick={() => nav("/momo/complete", { state: { msgs, sessionId } })} ariaLabel="일기로 완성">
            ✓
          </IconButton>
        }
      />
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <div style={{ flex: 1, overflowY: "auto", padding: "12px 18px 8px", display: "flex", flexDirection: "column", gap: 10 }}>
          {msgs.map((m) => (
            <div key={m.id} style={{ display: "flex", justifyContent: m.who === "me" ? "flex-end" : "flex-start" }}>
              {m.who === "momo" && (
                <div style={{ marginRight: 8 }}>
                  <Momo2D size={32} />
                </div>
              )}
              <div
                style={{
                  maxWidth: "75%",
                  padding: "10px 14px",
                  borderRadius: 18,
                  fontSize: 13.5,
                  lineHeight: 1.55,
                  background:
                    m.who === "me"
                      ? "linear-gradient(135deg,#7c6fe8,#a394f7)"
                      : "var(--iv-surf2)",
                  color: "#fff",
                  border: m.who === "me" ? "none" : "1px solid var(--iv-line)",
                }}
              >
                {m.text}
                {m.emo && (
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 5,
                      marginTop: 5,
                      fontSize: 11,
                      opacity: 0.9,
                    }}
                  >
                    <EmotionDot label={m.emo} />
                    {m.emo} 감지됨
                  </div>
                )}
                {m.memory && m.memory.length > 0 && (
                  <div style={{ marginTop: 6, fontSize: 10.5, lineHeight: 1.5, color: "#cdb8ff", opacity: 0.85 }}>
                    🧠 기억 참조 · {m.memory.join(" / ")}
                  </div>
                )}
              </div>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        {locked && (
          <div style={{ padding: "0 18px 8px" }}>
            <PlanNotice
              title="오늘의 대화를 다 썼어요"
              body="무료 플랜은 하루 15턴이에요. 플러스로 바꾸면 모모와 무제한으로 이야기할 수 있어요."
            />
          </div>
        )}

        <div style={{ padding: "0 18px 8px", display: "flex", gap: 6, overflowX: "auto" }}>
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              disabled={locked}
              onClick={() => send(s)}
              style={{
                fontSize: 11.5,
                padding: "6px 11px",
                borderRadius: 999,
                background: "rgba(255,255,255,.05)",
                color: "var(--iv-txt2)",
                border: "1px solid var(--iv-line)",
                cursor: "pointer",
                flex: "0 0 auto",
              }}
            >
              {s}
            </button>
          ))}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
          style={{ padding: "8px 18px 18px", display: "flex", gap: 8 }}
        >
          <input
            className="iv-input"
            disabled={locked}
            placeholder={locked ? "오늘의 대화 한도를 다 썼어요" : "모모에게 들려주기…"}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            style={{ flex: 1 }}
          />
          <button
            type="submit"
            disabled={locked}
            className="iv-iconbtn"
            style={{ background: "linear-gradient(135deg,#7c6fe8,#a394f7)", border: "none" }}
            aria-label="보내기"
          >
            ➤
          </button>
        </form>
      </div>
      <CareSheet open={careOpen} onClose={() => setCareOpen(false)} />
    </>
  );
}
